﻿Imports System.Data.SqlClient
Public Class Reportform

    Private Sub Reportform_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    Sub FillCustomerReport(ByVal sql As String)
        connect()
        Dim da As New SqlDataAdapter(sql, cn)
        Dim ds As New DataSet1()
        da.Fill(ds, "CustomerEntry")
        'Create an object of Report class
        Dim rpt As New CustReport()

        rpt.SetDataSource(ds) 'Filled report with data

        CrystalReportViewer1.ReportSource = rpt
        Module1.close()


    End Sub
    Sub FillEmployeeReport(ByVal sql As String)
        connect()
        Dim da As New SqlDataAdapter(sql, cn)
        Dim ds As New DataSet1()
        da.Fill(ds, "EmployeeEntry")
        'Create an object of Report class
        Dim rpt As New EmpReport()

        rpt.SetDataSource(ds) 'Filled report with data

        CrystalReportViewer1.ReportSource = rpt
        Module1.close()


    End Sub
    Sub FillItemReport(ByVal sql As String)
        connect()
        Dim da As New SqlDataAdapter(sql, cn)
        Dim ds As New DataSet1()
        da.Fill(ds, "Itemform")
        'Create an object of Report class
        Dim rpt As New ItemReport()

        rpt.SetDataSource(ds) 'Filled report with data

        CrystalReportViewer1.ReportSource = rpt
        Module1.close()


    End Sub
    Sub FillSupReport(ByVal sql As String)
        connect()
        Dim da As New SqlDataAdapter(sql, cn)
        Dim ds As New DataSet1()
        da.Fill(ds, "Supplierform")
        'Create an object of Report class
        Dim rpt As New SupplierReport()

        rpt.SetDataSource(ds) 'Filled report with data

        CrystalReportViewer1.ReportSource = rpt
        Module1.close()
    End Sub
    Sub FillBillingReport(ByVal sql As String)
        connect()
        Dim da As New SqlDataAdapter(sql, cn)
        Dim ds As New DataSet1()
        da.Fill(ds, "Billingform")
        'Create an object of Report class
        Dim rpt As New BillReport()

        rpt.SetDataSource(ds) 'Filled report with data

        CrystalReportViewer1.ReportSource = rpt
        Module1.close()
    End Sub
    Sub FillBillReport(ByVal sql As String)
        connect()
        Dim da As New SqlDataAdapter(sql, cn)
        Dim ds As New DataSet1()
        da.Fill(ds, "BillView")
        'Create an object of Report class
        Dim rpt As New BillingReport()

        rpt.SetDataSource(ds) 'Filled report with data

        CrystalReportViewer1.ReportSource = rpt
        Module1.close()
    End Sub

    Private Sub CrystalReportViewer1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrystalReportViewer1.Load

    End Sub
End Class